
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Home</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

<?php 
     include("contact.php");
	 ?>
	 <h2>

	 <form action="https://formsubmit.co/haroldabban8@gmail.com" method="POST">
        <input type="text" name="name" placeholder="name" required>
        <input type="hidden" name="_next" value="https://tailoredbyoboshie.com/pages/thankyou.html">
        <input type="email" name="email" placeholder="email address" required>
        <input type="location" name="location" placeholder="location" required>
        <button type="submit">Send</button>
 </form>
	 </h2>

<div class="d-flex justify-content-center align-items-center vh-100">
    	
    	<div class="shadow w-450 p-3 text-center">

	
		</div>
    </div>
   
	
    


</body>
</html>

<?php }else {
	header("Location: home.php");
	exit;
} ?>